a,b=map(int,input().split())
if b>0:
    k=a
    b=b-1
    while b:    
        a=a*k
        b=b-1
    print(a)
else:
    k=1/a
    b=b-1
    while b:
        a=a*k
        b=b+1
    print(round(a,3))