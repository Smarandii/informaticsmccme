def IsPrime(n):
   d = 2
   while n % d != 0:
      d += 1
   return d == n
l=0
n=int(input())
for i in range(2,n+2):
   for j in range(2,n+2):
      if IsPrime(i) and IsPrime(j):
         if i+j==n:
            print(i,j)
            l=1
            break
      if l==1:
         break