n=int(input())
if n==1:
    print("NO")
else:
    s=1
    for i in range(2,(n//2)):
        if n%i==0:
            s=s+i   
    if s==n:
        print("YES")
    else:
        print("NO")
                   
        