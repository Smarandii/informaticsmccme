x,y=map(float,input().split())
 
import math
 
o=False
 
if x<1 and y>1-x and y<2*x*x:
    o=True
if x<1 and y>1-x and y>2*x*x:
    o=True
if o:
    print("YES")
else:
    print("NO")
