def IsPrime(n):
   d=2
   while n%d!=0:
      d+=1
   return d==n
n=int(input())
if n==1:
   print("NO")
if IsPrime(n):
   print("YES")
else:
   print("NO")