a=int(input())
a1=0
k=0
s=1
s1=0
while a>0:
    s1=a%10
    a=a//10    
    s=a%10
    if s1==s:
        k=k+2
if k==2:
    print("YES")
else:
    print("NO")
