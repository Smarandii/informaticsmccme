n=int(input())
c=1
d=[]
old=2300
o_d=""
while n:
    i,f,date=str(input()).split(" ")
    k=int(date[0:2])+int(date[3:5])+int(date[6::])
    if k<=old:
        old=k 
        r=i+" "+f+" "+date
        o_d=date
    if o_d==date:
        d.append(o_d)
        
    n=n-1
if d.count(r[-10::])>1:
    print(d.count(r[-10::]))
else:
    print(r)