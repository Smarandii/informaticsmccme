a=float(input())
b=float(input())
n=(a**b)
print("%.3f" % n)