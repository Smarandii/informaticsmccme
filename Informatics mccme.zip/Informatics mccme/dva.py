a=str(input())
def dva(a):
    avc=[]
    for i in a:
        avc.append(i)
    for i in avc:
        if 2==avc.count(i):
            return i
print(dva(a))
    
