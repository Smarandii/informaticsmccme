a=int(input())
b=2
while b<=a:
    if a%b==0:
        print(b)
        break
    else:
        b+=1
