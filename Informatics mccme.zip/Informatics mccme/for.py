i = 1
for color in 'red', 'orange', 'yellow', 'green', 'cyan', 'blue', 'violet':
    print(i,'-th color of rainbow is ', color, sep = '')
    i += 1