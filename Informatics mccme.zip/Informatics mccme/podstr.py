a=str(input())
b=str(input())
def podstr(a):
    if a.find(b):
        return "yes"
    else:
        return "no"
print(podstr(a))
    
