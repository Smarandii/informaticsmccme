s=input()
s1=""
k=0
s=s.rstrip()
for i in s:
    if " "==i or "\n"==i or '\f'==i or '\r'==i or '\t'==i or '\v'==i:
        if s1=="":
            continue
        elif s1:
            k=k+1
            s1=""
            continue
    s1=s1+i
k=k+1
print(k)