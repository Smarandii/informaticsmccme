fp=list(map(int,input().split()))
sp=list(map(int,input().split()))
k=0
t=0

while sp and fp:
   t=t+1
   if t>1000000:
      break 
   
   if sp[0]==0 and fp[0]==9:
      sp.append(fp[0])
      sp.append(sp[0])
      del fp[0]
      del sp[0]
      k=k+1
      
   elif fp[0]==0 and sp[0]==9:
      fp.append(fp[0])
      fp.append(sp[0])
      del fp[0]
      del sp[0]
      k=k+1
      
   elif sp[0]>fp[0]:
      sp.append(fp[0])
      sp.append(sp[0])
      del sp[0]
      del fp[0]
      k=k+1

   elif fp[0]>sp[0]:
      fp.append(fp[0])
      fp.append(sp[0])
      del fp[0]
      del sp[0]
      k=k+1

if t>1000000:
   print("botva")
elif sp:
   print("second",k)
elif fp:
   print("first",k)
