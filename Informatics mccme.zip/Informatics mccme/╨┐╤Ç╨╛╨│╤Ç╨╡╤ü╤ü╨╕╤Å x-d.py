a,d,n=map(int,input().split())
z=n
b=[]
while n:
    b.append(a)
    a=a+d
    n=n-1

for i in range(z):
    print(b[i], end=" ")