a=str(input())
a=a+"o"
b=[]
num=""
j=0
alpha=""
k=0
bt=""
for i in range(len(a)):
    if a[i].isdigit():
        num=num+a[i]
        if k==0:
            alpha=alpha+"1"
            k=1
    if not a[i].isdigit():
        k=0
        alpha=alpha+a[i]
        if num!="":
            b.append(bin(int(num))[2::])
        num=""
for i in range(len(alpha)):
    if alpha[i].isdigit():
        bt=bt+b[j]
        j=j+1
    else:
        bt=bt+alpha[i]
print(bt[:-1:])


    