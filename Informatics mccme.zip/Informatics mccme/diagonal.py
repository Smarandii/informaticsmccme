n=int(input())
while n:
    n=n-1
    a.append(list(map(str,input()).split()))
print(a)