n,k=map(int,input().split())
a=[[]*k]*n
for i in range(k*n-len(a)+1):
    
    
    
        
for i in range(n):
    for j in range(k):
        if a[i][j].isdigit():
            if len(" "+a[i][j])!=3:
                a[i][j]=" "+a[i][j]
print(a)