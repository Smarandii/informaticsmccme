x,y=map(float,input().split())

import math

o=False

if x<0 and x*x+y*y<1 and y>-x:
    o=True
if x<0 and x*x+y*y<1 and y<x:
    o=True
if x>0 and x*x+y*y<1:
    o=True
if o:
    print("YES")
else:
    print("NO")