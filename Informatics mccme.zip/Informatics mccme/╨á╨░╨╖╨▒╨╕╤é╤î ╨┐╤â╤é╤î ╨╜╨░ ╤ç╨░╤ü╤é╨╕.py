s=input()
s1=""
k=0
for i in s:
    if " "==i:
        if s1=="":
            continue
        elif s1:
            k=k+1
            s1=""
            continue
    s1=s1+i
k=k+1
print(k)