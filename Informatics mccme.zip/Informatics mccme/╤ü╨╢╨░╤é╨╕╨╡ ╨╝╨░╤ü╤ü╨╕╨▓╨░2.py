n=int(input())
k=0
a=list(map(int,input().split()))
im=len(a)-1
used=[]
for i in range(0,len(a)):
    if a[i] not in used:
        used.append(a[i])
countzero=n-len(used)
while countzero:
    used.append(0)
    countzero=countzero-1
while im>=0:
    if used[im]==0:
        used.pop(im)
        used.append(0)
    im=im-1
for i in used:
    print(i,end=" ")