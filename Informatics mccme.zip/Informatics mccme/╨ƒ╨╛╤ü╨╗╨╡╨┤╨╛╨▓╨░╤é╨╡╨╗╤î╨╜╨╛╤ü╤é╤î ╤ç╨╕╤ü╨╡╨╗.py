k=0
a=1
while a!=0:
    a=int(input())
    k=k+1
print(k-1)