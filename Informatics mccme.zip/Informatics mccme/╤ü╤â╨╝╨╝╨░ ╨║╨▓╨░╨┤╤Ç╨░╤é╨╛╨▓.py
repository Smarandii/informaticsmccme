l=0
n=int(input())
r=round(n**0.5)+1
r1=round(r**0.5)-1
if n<=10000000:
   for i in range(r1,r):
      for j in range(r,r1,-1):
         if i*i+j*j==n:
            print(i,j)
            l=1
            break
      if l==1:
         break
else:
   r1=1000
   for i in range(r1,r):
      for j in range(r,r1,-1):
         if i*i+j*j==n:
            print(i,j)
            l=1
            break
      if l==1:
         break   
if l==0:
   print("Impossible")