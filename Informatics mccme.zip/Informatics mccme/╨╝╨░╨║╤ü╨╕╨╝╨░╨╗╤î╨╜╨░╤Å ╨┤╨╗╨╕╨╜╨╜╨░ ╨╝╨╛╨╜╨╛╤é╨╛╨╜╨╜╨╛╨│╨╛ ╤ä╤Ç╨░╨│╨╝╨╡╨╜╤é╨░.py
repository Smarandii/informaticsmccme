a=int(input())
k=a
l=1
u=1
while a:
    a=int(input())
    if a==0:
        break
    if a==k:
        l=l+1
    elif a!=k:
        l=1
    if u<l:
        u=l
    k=a
print(u)
