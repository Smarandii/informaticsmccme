n=int(input())
def main(n):
    k=0
    stack=[]
    while n:
        n=n-1
        com=str(input())
        if com=="-":
            print(stack.pop())
        else:
            op,ind=com.split()
            if op=="+":
                stack.insert(0,ind)
            elif op=="*":
                if len(stack)%2==0:
                    stack.insert(len(stack)//2,ind)
                else:
                    stack.insert(len(stack)//2+1,ind)
main(n)