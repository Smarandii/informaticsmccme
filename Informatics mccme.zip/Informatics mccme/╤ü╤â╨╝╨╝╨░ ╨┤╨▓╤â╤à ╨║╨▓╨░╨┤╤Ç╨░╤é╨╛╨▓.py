l=0
n=int(input())
for i in range(n):
   for j in range(n,0,-1):
      if i*i+j*j==n:
         print(i,j)
         l=1
         break
   if l==1:
      break
if l==0:
   print("Impossible")