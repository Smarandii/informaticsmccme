a=str(input())
def palindrom(a):
    b=a[-1:0]
    if a==b:
        return 'yes'
    else:
        return 'no'
        
    
