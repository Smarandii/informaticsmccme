n=int(input())
b=1
c=1
for i in range(0,n):
    a=c
    c=b
    b=a+b
print(a)