for i in range(100,1000):
    c=i
    i=i**2
    c1=i%10
    c1=str(c1)
    i=i//10
    c2=i%10
    c2=str(c2)
    i=i//10
    c3=i%10
    c3=str(c3)
    i=i//10
    cd=c3+c2+c1
    cd=int(cd)
    if cd==c:
        print(c)