n=int(input())

def SumOfDigits1(n):
    s1=0
    while n>0:
        i=n%10
        n=n//10
        s1=s1+i
        if n//10==0:
            s=n+s1
            print(s)
            return(s)
        elif n>0:
            continue

SumOfDigits1(n)
