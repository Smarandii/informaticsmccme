n,m=map(int,input().split(" "))
a=[]
for i in range(n):
    a.append([0]*m)
l=0
b=0
for i in range(len(a)):
    for j in range(len(a[i])):
        if l>=5+b:
            l=l-4
            b=b+1
            
        if i%2==0:
            if j%2==0:
                del a[i][j]
                a[i].insert(j,l)                
            else:
                del a[i][j]
                a[i].insert(j,l)
            l=l+1
            
            
        if i%2!=0:
            if j%2==0:
                del a[i][j]
                a[i].insert(j,l)                 
            else:
                del a[i][j]
                a[i].insert(j,l)
            l=l+1
for i in a:
    for j in i:
        print(j,end=" ")
    print()
