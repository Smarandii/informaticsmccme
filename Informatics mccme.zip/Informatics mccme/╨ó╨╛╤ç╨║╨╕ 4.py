x,y=map(float,input().split())

import math

o=True

if y<x*x-2:
    o=False
if y>=abs(x):
    o=False
if o:
    print("YES")
else:
    print("NO")