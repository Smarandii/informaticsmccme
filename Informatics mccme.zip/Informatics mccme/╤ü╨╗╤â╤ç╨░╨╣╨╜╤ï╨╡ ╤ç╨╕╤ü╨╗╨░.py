import random
a,b,c=map(int,input().split())
while c>0:
    print(random.randint(a,b), end=" ")
    c=c-1