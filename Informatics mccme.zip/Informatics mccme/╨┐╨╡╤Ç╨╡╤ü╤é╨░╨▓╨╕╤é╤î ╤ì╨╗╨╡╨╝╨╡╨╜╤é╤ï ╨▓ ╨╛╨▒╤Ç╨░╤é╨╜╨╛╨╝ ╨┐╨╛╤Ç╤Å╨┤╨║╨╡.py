n=int(input())
k=0
a=list(map(int,input().split()))
a.reverse()
for i in range(0,len(a)):
    print(a[i], end=" ")
        
        