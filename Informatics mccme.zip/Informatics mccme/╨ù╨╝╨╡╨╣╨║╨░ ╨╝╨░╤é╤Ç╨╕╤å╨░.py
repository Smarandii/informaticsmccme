n,m=map(int,input().split())
a =[0]*n
if n*m<10:
    b = ["  "+str(x) for x in range(1,m*n+1) if len(str(x))==1 ]
if n*m>=10:
    b = ["  "+str(x) for x in range(1,m*n+1) if len(str(x))==1 ]
    b1 = [" "+str(x) for x in range(int(b[-1])+1,m*n+1) if len(str(x))==2]
    b=b+b1
if n*m>=100:
    b = ["  "+str(x) for x in range(1,m*n+1) if len(str(x))==1 ]
    b1 = [" "+str(x) for x in range(int(b[-1])+1,m*n+1) if len(str(x))==2]
    b2 = [str(x) for x in range(int(b1[-1])+1,m*n+1)]
    b=b+b1+b2


for i in range(n):
    a[i] = [" "] * m

for i in range(n):
    if i%2==0:
        a[i]=b[:m:]
        b=b[m::]
    else:
        a[i]=b[:m:]
        a[i].reverse()
        b=b[m::]
for i in a:
    print(*i)