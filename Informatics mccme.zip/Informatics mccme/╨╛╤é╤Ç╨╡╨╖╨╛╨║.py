a,b,c,d=map(int,input().split())
m=abs(a-c)
n=abs(b-d)
s=m+n
while n and m:
    if n>m:
        n=n%m
    else:
        m=m%n
t=m+n
print(s-t)
