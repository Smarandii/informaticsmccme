s=input()
s1=""
k=0
for i in s:
    if i=="a":
        s1=s1+"b"
        k=k+1
    elif i=="A":
        s1=s1+"B"
        k=k+1
    elif i=="b":
        s1=s1+"a"
        k=k+1
    elif i=="B":
        s1=s1+"A"
        k=k+1
    else:
        s1=s1+i
print(s1)
print(k)