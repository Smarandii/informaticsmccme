n=int(input())
a=list(map(int,input().split()))
k=a.copy()
k.sort()
km=a.copy()
km.sort()
i=0
l=0
while a!=km:
    if i>n-1:
        i=0
    if a[i]==k[-1]:
        for j in range(i,len(k)-1):
            a.insert(j+2,k[-1])
            a.pop(a.index(k[-1]))
            print(*a)
            l=1
        k.pop(-1)
    i=i+1

if l==0:
    print(0)
        