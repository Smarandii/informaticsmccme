n=int(input())
def proverka(n):
   d = 2
   while n % d != 0:
      d += 1
   return d == n
if proverka()==True:
   o=1
n=str(n)
n2=n[1:-2:]
n1=n[-2::]
print(n2,n1)
