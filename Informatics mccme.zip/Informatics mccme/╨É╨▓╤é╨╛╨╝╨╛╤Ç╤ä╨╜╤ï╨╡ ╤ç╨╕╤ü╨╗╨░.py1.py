a=int(input())
b=int(input())
d=0
o=0
for i in range(a,b):
    d=10
    while d<=i:
        d=d*10
    if i*i%d==i:
        print(i, end=" ")
    elif i*i%d!=i:
        o=o+1
if o==b:
    print(-1, o)
    
