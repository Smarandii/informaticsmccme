a,b=map(int,input().split(" "))
a1,b1=a,b
while a!=0 and b!=0:
    if a>b:
        a=a%b
    else:
        b=b%a
nod=a+b
proiz=a1*b1
print(round(proiz/nod))