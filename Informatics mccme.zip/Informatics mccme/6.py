x,y= map(float, input().split())
print(round(x**y,3))