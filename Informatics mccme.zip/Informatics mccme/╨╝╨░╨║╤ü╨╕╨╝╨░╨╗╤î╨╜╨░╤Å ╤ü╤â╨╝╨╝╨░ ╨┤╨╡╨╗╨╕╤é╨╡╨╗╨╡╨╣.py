n=int(input())

def sumdel(i):
    sumd=0
    for j in range(1,(i//2)+1):
        if i%j==0:
            sumd+=j
    return sumd+i

def result():
    maxsumd=0
    for i in range(n-d,n+1):
        if sumdel(i)>maxsumd:
            maxsumd=sumdel(i)
            resultat=i
    return resultat

if 0<n<=10:
    d=n-1
    print(result())
if 10<n<=100:
    d=10
    print(result())
elif 100<n<=1000:
    d=100
    print(result())
elif 1000<n<=10000:
    d=1000
    print(result())
