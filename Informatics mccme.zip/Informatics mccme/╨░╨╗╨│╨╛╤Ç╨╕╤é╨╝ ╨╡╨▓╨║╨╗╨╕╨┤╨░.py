n=int(input())
m=int(input())
while n!=m and n and m and m!=n:
    if n>m:
        n=n%m
    else:
        m=m%n
print(n+m)