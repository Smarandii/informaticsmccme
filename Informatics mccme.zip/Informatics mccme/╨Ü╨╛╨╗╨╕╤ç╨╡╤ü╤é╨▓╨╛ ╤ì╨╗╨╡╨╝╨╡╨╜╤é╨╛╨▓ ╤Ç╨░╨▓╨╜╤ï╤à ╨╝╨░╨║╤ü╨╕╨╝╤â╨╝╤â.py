k=0
s=0
a=1
while a!=0: 
    if a>s:
        s=a    
    a=int(input())
    if a==s:
        k=k+1
print(k)        
    
