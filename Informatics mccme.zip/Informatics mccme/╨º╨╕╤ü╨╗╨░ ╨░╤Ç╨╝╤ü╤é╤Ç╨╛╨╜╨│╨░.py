a,b=map(int,input().split())
f=0
for i in range(a,b + 1):
      c=i
      s=0
      k=0
      while c > 0:
            c = c//10
            k=k+1
      c=i
      while c>0:
            x=c%10
            c=c//10
            s=s+x**k
      if s==i:
            print(i,' ',end="", sep="")
            f=1
if f!=1:
      print(-1)