n=int(input())
b=[]
b1=[]
a1=[]
a2=[]
a=list(map(int, input().split()))
for i in range(len(a)//2):
    b.append(a[i])
    a1.append(a[i+len(a)//2])
for i in range(len(b)-1,-1,-1):
    b1.append(b[i])
for i in range(len(a1)-1,-1,-1):
    a2.append(a1[i])
for i in range(len(b1)):
    a[i]=b1[i]
for i in range(len(a)//2,len(a)):
    a[i]=a2[i-len(a)//2]
for i in range(len(a)):
    print(a[i], end=" ")