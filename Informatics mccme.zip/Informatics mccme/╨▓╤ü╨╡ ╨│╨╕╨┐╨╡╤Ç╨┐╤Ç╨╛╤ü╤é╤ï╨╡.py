def IsPrime(n):
   d=2
   while n%d!=0:
      d+=1
   return d==n



l,l1=map(int,input().split())
o=0
for n in range(l,l1+1):
   if n==1:
      continue
   else:
      if len(str(n))>2:
         k=str(n)
         n1=int(k[0:-1])
         n2=int(k[0:-2])
         if n1==1 or n2==1:
            continue
         if IsPrime(n) and IsPrime(n1) and IsPrime(n2):
            print(n,end=" ")
            o=1
         else:
            continue
      elif IsPrime(n) and len(str(n))==1:
         print(n,end=" ")
         o=1
      elif len(str(n))==2:
         k=str(n)
         n1=int(k[0:-1])
         if n1==1:
            continue
         else:
            if IsPrime(n) and IsPrime(n1):
               print(n,end=" ")
               o=1
            else:
               continue
if o!=1:
   print(0)