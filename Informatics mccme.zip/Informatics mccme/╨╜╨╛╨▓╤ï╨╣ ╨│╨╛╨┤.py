a,b=map(int,input().split())
if a<=0 or a>12 or b>31 or b<=0:
    print(-1)
elif (a==2 and b>28) or (a==4 and b>30) or (a==6 and b>30) or (a==9 and b>30) or (a==11 and b>30):
    print(-1)    
else:
    if a==1 and b<=31:
        o=365-b
        print(o)
    elif a==2:
        d=28-b
        o=d+6*31+4*30
        print(o)
    elif a==3:
        d=31-b
        o=d+5*31+4*30    
        print(o)             
    elif a==4:
        d=30-b
        o=d+5*31+3*30    
        print(o)           
    elif a==5:    
        d=31-b
        o=d+4*31+3*30    
        print(o)            
    elif a==6:   
        d=30-b
        o=d+4*31+2*30     
        print(o)           
    elif a==7:  
        d=31-b
        o=d+3*31+2*30      
        print(o)           
    elif a==8:
        d=31-b
        o=d+2*31+2*30      
        print(o)                    
    elif a==9:
        d=30-b
        o=d+2*31+1*30      
        print(o)            
    elif a==10:
        d=31-b
        o=d+1*31+1*30      
        print(o)                           
    elif a==11:
        d=30-b
        o=d+1*31      
        print(o)                       
    elif a==12:
        d=31-b
        o=d    
        print(o)