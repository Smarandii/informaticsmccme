n=int(input())
def MinDigit(n):
        k=n%10
        d=n//10
        if k>d:
                print(d, k)
        elif k==d:
                print(k, d)
        elif d>k:
                print(k, d)
MinDigit(n)
