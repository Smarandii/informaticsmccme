n, m =(map(int, input().split())) 
a = [] 
for i in range(n): 
    a.append(list(map(int, input().split()))) 
maxim=0 
N=[0]*n 
for i in range(n): 
    for q in range(m): 
        N[i]=N[i]+a[i][q] 
maxim=N[0] 
noscore=0 
for i in range (n): 
    if maxim<N[i]: 
        maxim=N[i] 
        noscore=i 
print(maxim) 
print(noscore)