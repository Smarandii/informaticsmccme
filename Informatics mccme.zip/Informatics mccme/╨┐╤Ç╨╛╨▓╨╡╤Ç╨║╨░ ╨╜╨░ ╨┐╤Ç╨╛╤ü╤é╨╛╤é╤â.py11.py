a=int(input())
h=a/2
j=0
o=0
for i in range(1,11):
    k=a//i
    if a%i==0:
        if k==a or k==1:
            continue 
        else:
            o=o+1
if a==1:
    print("NO")
elif o!=0:
    print("NO")
else:
    print("YES")