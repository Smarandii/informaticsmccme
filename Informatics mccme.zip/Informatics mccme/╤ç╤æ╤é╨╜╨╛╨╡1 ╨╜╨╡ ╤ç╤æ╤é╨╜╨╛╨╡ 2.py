if a%2==0:
    i=1
    print(i)
elif a%2>0:
    o=2
    print(o)