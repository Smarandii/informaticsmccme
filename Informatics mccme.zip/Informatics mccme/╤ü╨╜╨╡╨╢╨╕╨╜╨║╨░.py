n=int(input())
a=[[" "]*n]*n
print(a)
print(a[0][0])
for i in range(n):
    for j in range(n):
        print(i,j)
        print(a)
        if i==j:
            a[i].insert(j,"*")
            a[i].pop()
        if j==n//2:
            a[i].insert(j,"*")
            a[i].pop()
        if i==n//2:
            a[i].insert(j,"*")
            a[i].pop()
        if j+i==n-1:
            a[i].insert(j,"*")
            a[i].pop()
        else:
            continue

for i in a:
    print(*i)