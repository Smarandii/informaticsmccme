a=int(input())
if a>12 or a<1:
    print(0)
if a==1 or a==12 or a==3 or a==5 or a==7 or a==8 or a==10:
    print(31)
if a==2:
    print(28)
if a==4 or a==6 or a==9 or a==11:
    print(30)