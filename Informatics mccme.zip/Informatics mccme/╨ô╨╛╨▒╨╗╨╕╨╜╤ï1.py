n=int(input())
line=[]
done=[]
def appendLine(option,ind):
    if option=="+":
        line.append(ind)
    elif option=="*":
        if len(line)%2==0:
            line.insert(len(line)//2,ind)
        else:
            line.insert(len(line)//2+1,ind)
def nextPls():
    done.append(line[0])
    line.pop(0)
    return done

while n:
    n=n-1
    com=str(input())
    if com=="-":
        done=nextPls()
        continue
    else:
        option,ind=com.split(" ")
        appendLine(option,ind)
        
for i in done:
    print(i)