a=set(int,input().split())
print(a)
    
    