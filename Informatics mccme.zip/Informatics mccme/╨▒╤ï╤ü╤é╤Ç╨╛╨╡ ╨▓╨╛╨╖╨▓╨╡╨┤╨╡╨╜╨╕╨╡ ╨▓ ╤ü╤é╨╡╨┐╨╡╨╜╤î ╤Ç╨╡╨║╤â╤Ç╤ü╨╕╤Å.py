def power(): 
    f=(a*a)**(n/2) 
    return f 
def power1(): 
    f=a*(a**(n-1)) 
    return f
    
    
a=float(input()) 
n=int(input())  
if n&2==0: 
    print(round(power(),5)) 
else: 
    print(round(power1(),5))