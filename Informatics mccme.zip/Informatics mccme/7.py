a=str(input())
b=a[:1]
v=a[1:2]
c=a[2:3]
print(b,v,c)