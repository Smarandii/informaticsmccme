n=int(input())
k=0
if n==1:
    print(9)
elif n==2:
    print(9)
elif n>2:
    if n%2==0:
        a=[]
        b=[]
        for i in range(1,(n//2)+1):
            a.append(0)
            b.append(0)
        