n,m=map(int,input().split(" "))
a1=[]
a=[]
r=[]
v=[]
max1=0
for i in range(n):
    a.append(list(map(int,input().split())))


for i in range(len(a)):
    for j in range(len(a[i])):
        if a[i][j]>max1:
            max1=a[i][j]
            
for i in range(len(a)):
    a1.append(a[i])
    
for i in range(len(a1)):
    for j in range(len(a1[i])):
        if a1[i][j]==max1:
            r.append(j)
            del a1[i][j]
            a1[i].insert(j,"l")

p=len(r)
while p:
    for i in range(len(a)):
        for j in range(len(a[i])):        
            if j in r:
                if a[i][j]=="r":
                    continue
                if a[i][j]=="l":
                    v.append(max1)
                    del a[i][j]
                    a[i].insert(j,"r")
                    break                    
                else:
                    v.append(a[i][j])
                    del a[i][j]
                    a[i].insert(j,"r")
                    break
    p=p-1
for i in range(len(v)):
    if i<=n-1:
        print(v[i],end=" ")
    if i%n==0 and i!=0:
        print()
    if i>=n:
        print(v[i],end=" ")