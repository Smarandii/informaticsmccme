n=int(input())
k=list(map(int,input().split()))
m=[]
p=3
while p:
    p=p-1
    m.append(k.pop(k.index(min(k))))
m.sort()
print(*m,*k)