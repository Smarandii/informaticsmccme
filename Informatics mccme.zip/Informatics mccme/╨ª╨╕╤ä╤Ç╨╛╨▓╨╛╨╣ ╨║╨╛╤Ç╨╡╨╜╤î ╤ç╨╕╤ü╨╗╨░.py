n=str(input())
k=0
while len(n)!=1:
    for i in n:
        k=k+int(i)
    n=str(k)
    k=0
print(n)