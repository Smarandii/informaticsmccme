k=int(input())
if k>=1 and k<=100000:
    n=k%2
else:
    print("NO")
if n>0:
    print("NO")
m=k//2     
if m%2>0:
    print("NO")
if m%5>0:
    print("NO")
if m%10>0:
    print("NO")
if m%50>0:
    print("NO")
if m%100>0:
    print("NO")
if m%500>0:
    print("NO")
if m%1000>0:
    print("NO")
if m%5000>0:
    print("NO")
else:
    print("YES")
