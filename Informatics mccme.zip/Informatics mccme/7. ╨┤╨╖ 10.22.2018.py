a=0
b=0
c=0
r=int(input())
r2=r*r
for x in range(1,r+1):
    x2=x*x
    c=c+int((r2-x2)**0.5)
c=4*(c+r)+1
print(c)
