a=str(input())
print(len(a))