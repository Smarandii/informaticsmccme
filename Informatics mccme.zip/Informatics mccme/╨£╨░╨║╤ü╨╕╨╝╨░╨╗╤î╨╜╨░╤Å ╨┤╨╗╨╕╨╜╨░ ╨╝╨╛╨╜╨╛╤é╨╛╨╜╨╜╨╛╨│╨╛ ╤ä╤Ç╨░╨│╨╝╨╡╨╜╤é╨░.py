b=int(input())
a=int(input())
k=1
c=1
while a:
    while a>b:
        if a==0:
            break
        k=k+1
        if k>c:
            c=k
            b=a
            a=int(input())
        else:
            b=a
            a=int(input())
    k=1
    while a<b:
        if a==0:
            break
        k=k+1
        if k>c:
            c=k
            b=a
            a=int(input())
        else:
            b=a
            a=int(input())
    k=1
    while a==b:
        k=1
        b=a
        a=int(input())
print(c)
        