a,b=map(int,input().split())
t=a
while t<=b:
    t1=t
    vivod = True
    while t>0:
        k=t%10
        t=t//10
        if k!=0 and t1%k!=0 or k==0:
            vivod = False
    t+=1
    if vivod: print(t1,end=" ")