a=str(input())
def pr(a):
    for i in a:
        if i.isdigit()==False:
            return "NO"
        if int(i)>8:
            return "NO"    
    return "YES"
print(pr(a))