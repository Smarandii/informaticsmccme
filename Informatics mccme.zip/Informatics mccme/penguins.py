n=int(input())
p1="   _~_    "
p2="  (o o)   "   
p3=" /  V  \  "  
p4="/(  _  )\ " 
p5="  ^^ ^^   "
a=[]
def penguins(n):
    pp1=''
    pp2=''
    pp3=''
    pp4=''
    pp5=''
    for i in range(n):
        a.append(p1)
        a.append(p2)
        a.append(p3)
        a.append(p4)
        a.append(p5)
    for i in range(n):
        pp1=a[0]+pp1
        pp2=a[1]+pp2
        pp3=a[2]+pp3
        pp4=a[3]+pp4
        pp5=a[4]+pp5
    print(pp1)
    print(pp2)
    print(pp3)
    print(pp4)
    print(pp5)
    
penguins(n)