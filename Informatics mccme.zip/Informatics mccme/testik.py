n=int(input())
q=0
while n//10!=0:
    a=str(n)
    o=n%10
    if proverka(o):
        q=q+1
    a=a[1:-2]
    n=int(a)
print(q,
    