n=int(input())
a=[]
b=[]
a=list(map(int,input().split()))
for i in range(0,len(a),3):
    b.append(a[i])
print(*b)