n=int(input())
a=[]
for i in range(0,n):
    y=input()
    a.append(y)
o=len(a)
c=a[-1]
m=a[0:-1:]
a[1]=m
a[0]=c

while o!=2:
    o=o-1
    a.pop()    
    for i in range(len(a)):
        for j in range(len(a[i])):
            print(a[i][j], end=' ')
        
        
        