n = input() 
n = int(n) 
fac = 1 
i = 0 
while i < n:
     i += 1
     fac = fac * i 
print (fac)
