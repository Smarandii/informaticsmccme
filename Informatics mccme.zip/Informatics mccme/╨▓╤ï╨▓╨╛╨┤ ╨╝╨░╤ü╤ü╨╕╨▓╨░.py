a=list(map(int,input()))
for i in range(len(A)):
    for j in range(len(A[i])):
        print(A[i][j], end=' ')
    print()