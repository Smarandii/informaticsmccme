s=0
n=int(input())
def summ(n):
    s=s+n
    if n:
        n=int(input())
        summ(n)
    else:
        print(s)
summ(n)