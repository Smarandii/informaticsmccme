a=int(input())
c=list(map(int,input().split()))
k=0
for i in range(len(c)):
    if c[i]<0:
        print(c[i], end=" ")
        k=1
if k!=1:
    print(0)