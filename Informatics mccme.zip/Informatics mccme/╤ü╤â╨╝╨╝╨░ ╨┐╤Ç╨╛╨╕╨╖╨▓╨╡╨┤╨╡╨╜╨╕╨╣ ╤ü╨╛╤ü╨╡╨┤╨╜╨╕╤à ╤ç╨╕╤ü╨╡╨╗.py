n=int(input())
s1=0
for i in range(1,n):
    s=i*(i+1)
    s1=s+s1
print(s1)
    