a=1
s=0
k=0
while a!=0: 
    a=int(input())
    if s<a:
        k=k+1
    s=a
print(k-1)    
