a=int(input())
k=0
o=0
for i in range(a): 
    b=map(int,input().split())
    if b>k:
        b==k
        m=a
    a=a-1
    o=o+1
print(m+1)
        