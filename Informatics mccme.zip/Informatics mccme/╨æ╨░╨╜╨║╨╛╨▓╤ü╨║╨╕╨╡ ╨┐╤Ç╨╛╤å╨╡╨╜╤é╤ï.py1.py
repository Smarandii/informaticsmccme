x=int(input())
p=int(input())
y=int(input())
k=0
while x<y:
    l=(x*p)//100
    x=l+x
    k=k+1
print(k)
    