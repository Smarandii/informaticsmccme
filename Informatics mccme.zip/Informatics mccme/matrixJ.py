n,m=map(int,input().split(" "))
a=[]
for i in range(n):
    a.append([0]*m)

for i in range(len(a)):
    for j in range(len(a[i])):
        if i%2==0:
            if j%2==0:
                continue
            else:
                del a[i][j]
                a[i].insert(j,1)
        if i%2!=0:
            if j%2==0:
                del a[i][j]
                a[i].insert(j,1)                 
            else:
                continue         
for i in a:
    for j in i:
        print(j,end=" ")
    print()
