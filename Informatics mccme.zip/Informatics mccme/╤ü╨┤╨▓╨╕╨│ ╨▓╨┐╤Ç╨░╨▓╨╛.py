n=int(input())
a=list(map(int,input().split()))
re,ge=map(int,input().split())
sdv=int(input())
sdvig=[]
dlinaMas=len(a)
p=sdv
for i in range(re+1,ge):
    sdvig.append(a[i])
dlinaSdv=len(sdvig)
print(sdvig,a)
k=len(sdvig)-1
while k>=0:
    a.insert(,sdvig[k])
    k=k-1
    
for i in a:
    print(i,end=" ")

    