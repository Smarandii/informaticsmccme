n=int(input())
if (n>10 and n%10==1 and n!=11) or n==1:
    print(n, "korova")
elif (n%10==2 or n%10==3 or n%10==4 or n//2==1 or n//3==1 or n//4==1) and (n>20 or n<5):
    print(n, "korovy")
elif n%10==5 or n%10==6 or n%10==7 or n%10==8 or n%10==9 or n%10==0 or n>=5 and n<=20:
    print("korov")
    