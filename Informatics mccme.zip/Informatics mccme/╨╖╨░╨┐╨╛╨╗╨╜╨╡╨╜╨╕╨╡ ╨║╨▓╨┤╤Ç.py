a=int(input())
z=a
b=[]
while a:
    b.append(a)
    a=a-1
b.reverse()
for i in range(z):
    print(b[i]**2, end=" ")