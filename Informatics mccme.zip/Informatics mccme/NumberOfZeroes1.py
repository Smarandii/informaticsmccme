n=int(input())

def NumberOfZeroes1(n):
    s1=0
    while n>=10:
        i=n%10
        n=n-i
        if n%10==0 and n>0:
            s1=s1+1
            n=n//10
            if n%10!=0: print(s1)
    else:
        print(0)

NumberOfZeroes1(n)