n,k = map(int,input().split())
a = list(map(int,input().split()))
b = list(map(int,input().split()))
 
def search(li,x):        
    i = 0
    j = len(li)-1
    m = int(j/2)
    while li[m] != x and i <= j:
        if x > li[m]:
            i = m+1
        else:
            j = m-1
        m = int((i+j)/2)
     
     
    if i > j:
        return "NO"
    else:
        return "YES"
 
for key in b:
    print(search(a,key))