n=int(input())

def NumberOfZeroes(n):
    s1=0
    while n>=10:
        if n%10==0 and n>0:
            s1=s1+1
            n=n//10
            if n%10!=0: print(s1)
        else:
            print(0)
NumberOfZeroes(n)