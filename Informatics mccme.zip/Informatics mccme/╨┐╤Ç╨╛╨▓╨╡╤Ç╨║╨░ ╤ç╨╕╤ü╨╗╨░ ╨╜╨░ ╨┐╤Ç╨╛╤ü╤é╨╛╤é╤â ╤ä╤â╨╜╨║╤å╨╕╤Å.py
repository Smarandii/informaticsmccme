d=2
def IsPrime(n):
    global d
    if d*d<=n and n%d!=0:
        d=d+1
        return IsPrime(n)
    if d*d>n:
        return "YES"
    else:
        return "NO"


x=int(input())
print(IsPrime(x))