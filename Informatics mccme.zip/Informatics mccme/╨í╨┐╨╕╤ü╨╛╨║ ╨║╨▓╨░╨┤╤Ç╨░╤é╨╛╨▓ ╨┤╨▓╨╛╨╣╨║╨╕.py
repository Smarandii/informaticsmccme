a=int(input())
s=1
for i in range(0,a):
    if s<=a:
        print(s, end=" ")
        s=s*2
    else:
        break
