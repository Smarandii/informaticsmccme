a=str(input())
def od(a):
    s=[]
    for i in a:
        if a.count(i)==1:
            s.append(ord(i))
        else:
            continue
    return s
s=od(a)
l=""
if s:
    s.sort()
    for i in s:
        l=l+chr(i)
    print(l)
else:
    print("NO")