a=str(input())
s=""
num=[]
for i in a:    
    if i.isdigit():
        s=s+i
for i in range(0,10):
    if str(i) in s:
        continue
    else:
        num.append(i)
if num:
    num.sort()
    num.reverse()
    for i in num:
        print(i,end="")
else:
    print("NO")