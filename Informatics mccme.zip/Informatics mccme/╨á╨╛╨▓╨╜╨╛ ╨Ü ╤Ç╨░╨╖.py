n=int(input())
a=list(map(int,input().split()))
k=int(input())
stack=[]
for i in a:
    if (a.count(i)==k) and (i not in stack):
        stack.append(i)
stack.sort()
if stack:
    print(*stack)
else:
    print(0)