n=int(input())
if n<=10000:
        u=0
        sv1=0
        svo=0   
        nsh=0
        for i in range(n+1):
                if i%2!=0:         
                        v=1/(2*i+1)
                        sv1=v
                        nsh=1-sv1
                elif i%2==0 and i!=0:
                        v=1/(2*i+1)
                        sv2=sv1+v
                if i>1:
                        print(svo)
                         
        if i>1:
                print(abs(round(svo,6)))
        else:
                print(round(nsh,6))
        