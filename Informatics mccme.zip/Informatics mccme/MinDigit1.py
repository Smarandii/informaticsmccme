n=int(input())

def MinDigit(n):
        d=100
        while d>=10:
                k=n%10
                d=n//10
                if d<10:
                        if k>d:
                                print(d, k)
                                break
                        elif k==d:
                                print(k, d)
                                break
                        elif d>k:
                                print(k, d)
                                break
                
MinDigit(n)
