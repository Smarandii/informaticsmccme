import random
a=[]
n=int(input())
for i in range(1,n+1):
    a.append(i)
random.shuffle(a)
a.remove(5)
a.insert(0,5)
for i in range(len(a)):
    print(a[i], end=" ")