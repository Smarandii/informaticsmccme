x1=int(input())
y1=int(input())
x2=int(input())
y2=int(input())
if (x2>x1 and y2<y1) and x1+y1==x2+y2:  
    print("YES")
elif (x2<x1 and y2>y1) and x1+y1==x2+y2:
    print("YES")
elif (x2<x1 and y2<y1) and abs(x1-x2) == abs(y1-y2):
    print("YES")
elif (x2>x1 and y2>y1) and abs(x1-x2) == abs(y1-y2):
    print("YES")
elif x1:
    print("NO")
    