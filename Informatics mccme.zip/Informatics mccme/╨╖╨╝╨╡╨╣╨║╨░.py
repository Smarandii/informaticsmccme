n,m=map(int,input().split())
space="   "
itog="  "
chis1=1
for i in range(1,n+1):
    print(i)
    if i%2!=0:
        chis=m*i
        for j in range(chis1, chis+1):
            if j==chis+1:
                itog=itog+str(j)+" "+"n/"
            if j==chis1:
                itog=itog+str(j)
            else:
                itog=itog+space+str(j)
    if i%2==0:
        for j in range(chis+m, chis+1,-1):
            if j==chis+1:
                itog=itog+str(j)+" "+"n/"
            if j==chis+m:
                itog=itog+str(j)            
            itog=itog+space+str(j)         
print(itog)