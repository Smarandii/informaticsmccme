n=int(input())
a=[]
k=0
o=0
for i in range(0,n):
    y=(map(int,input().split()))
    
    a.append(y)
    if a[i]>k:
        k=y

for i in range(0,n):
    if a[i]==k:
        o=o+1
print(o)