a=int(input())
while a>1:
    if a%2==1:
        break
    n=n//2
    print(n=1)