x=int(input()
m==0
l==0 
while x>0:
    l=l+1
    if m<x:
        m=(x%10)*2
    x=x//10
print(l,m)