print(0)
