a=int(input())
b=int(input())
for i in range(a,b+1):
    while i%2==0:
        print(i,end=" ")
        break
    