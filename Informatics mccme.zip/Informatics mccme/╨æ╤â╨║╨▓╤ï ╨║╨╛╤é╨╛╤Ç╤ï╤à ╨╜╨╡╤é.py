b1=str(input())
b=str(input())
a=b1.lower()+b.lower()
alp=''
for i in range(0,26):
    if chr(i+97) in a:
        continue
    else:
        alp=alp+chr(i+97)
if alp:
    print(alp.upper())
else:
    print(0)