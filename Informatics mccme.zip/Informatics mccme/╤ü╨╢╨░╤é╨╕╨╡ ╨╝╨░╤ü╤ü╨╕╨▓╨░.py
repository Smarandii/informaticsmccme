n=int(input())
a=[]
k=0
a=list(map(int,input().split()))
i=len(a)-1
while i>=0:
    if a[i]==0:
        a.pop(i)
        a.append(0)
    i=i-1
for i in a:
    print(i, end=" ")