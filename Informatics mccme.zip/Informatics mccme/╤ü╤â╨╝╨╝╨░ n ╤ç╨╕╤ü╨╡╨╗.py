s=0
n=int(input())
for i in range(n):
    a=int(input())
    s=a+s
print(s)    