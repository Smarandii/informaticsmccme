n,k = map(int,input().split())
a = list(map(int,input().split()))
b = list(map(int,input().split()))
b.sort()
zn=[]
min_r=100000
max_r=min(a)
for key in b:
    for i in range(len(a)):
        if a[i]-key<min_r:
            min_r=a[i]-key
            zn.append(key+min_r) 
    print(min(zn))
    zn=[]
    