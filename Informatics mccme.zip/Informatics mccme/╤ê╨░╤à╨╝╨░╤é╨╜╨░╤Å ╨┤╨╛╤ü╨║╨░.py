y1=int(input())  
x1=int(input())
y2=int(input()) 
x2=int(input())
s1=y1+x1; s2=y2+x2
if s1%2==0:
    b=(s2%2==0)
else:
    b=(s2%2!=0)
if b:
    print("YES")
else:
    print("NO")