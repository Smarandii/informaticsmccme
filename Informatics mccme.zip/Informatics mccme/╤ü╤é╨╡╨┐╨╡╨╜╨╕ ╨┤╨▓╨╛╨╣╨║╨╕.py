n=int(input())
a=2
z=n
b=[]
while n:
    b.append(a)
    a=a*2
    n=n-1
b.reverse()
for i in range(z):
    print(b[i], end=" ")