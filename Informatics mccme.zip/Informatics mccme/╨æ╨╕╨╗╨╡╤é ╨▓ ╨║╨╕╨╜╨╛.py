n,m,k=map(int,input().split())
a=[]
free=[]
pm=1
done=0
r=0
while n:
    n=n-1
    a.append(list(map(int,input().split())))
for i in range(len(a)):
    for j in range(len(a[i])):
        if a[i][j]==0:
            free.append(str(i)+str(j))

for i in range(len(free)-1):
    if (free[i][:1:] == free[i+1][:1:]) and r==free[i][:1:]:
        if int(free[i+1])-int(free[i])==1:
            pm=pm+1
    elif (free[i][:1:] == free[i+1][:1:]) and r!=free[i][:1:]:
        if k<pm:
            print("YES")
            done=1
        else:
            r=free[i][:1:]
            pm=1
            if int(free[i+1])-int(free[i])==1:
                pm=pm+1
if k==1 and len(free)==1:
    print("YES")
elif len(free)==0:
    print("NO")
elif k<pm and done==0:
    print("YES")
elif k>pm:
    print("NO")