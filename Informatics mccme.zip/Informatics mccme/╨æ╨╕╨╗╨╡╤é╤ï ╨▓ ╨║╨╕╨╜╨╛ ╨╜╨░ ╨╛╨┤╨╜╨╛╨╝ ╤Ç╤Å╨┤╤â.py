n,m,k=map(int,input().split())
a=[]
result="NO"
y=0
while n:
    a.append(list(map(str,input().split())))
    n-=1
for i in a:
    if i.count("0")>=k:
        l=k
        for j in range(len(i)):
            if i[j]!="0" and y==1:
                y=0
                l=k
            elif i[j]=="0":
                y=1
                l=l-1
                if l==0:
                    result="YES"
                    break
                
print(result)
                