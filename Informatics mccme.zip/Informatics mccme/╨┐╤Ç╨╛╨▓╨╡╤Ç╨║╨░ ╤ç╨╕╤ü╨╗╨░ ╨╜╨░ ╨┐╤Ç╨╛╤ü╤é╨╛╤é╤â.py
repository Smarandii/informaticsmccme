def IsPrime(n):
   d = 2
   while d * d <= n and n % d != 0:
      d += 1
   if d * d > n:
      return "YES"
   else:
      return "NO"

x=int(input())
print(IsPrime(x))