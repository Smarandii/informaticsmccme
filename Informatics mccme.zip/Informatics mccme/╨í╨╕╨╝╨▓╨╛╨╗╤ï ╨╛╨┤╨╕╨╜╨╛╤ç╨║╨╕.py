a=str(input())
def od(a):
    s=[]
    for i in a:
        if a.count(i)==1:
            s.append(ord(i))
        else:
            continue
    return s
s=od(a)
if s:
    i=0
    l=""
    while s:
        if s[i]==min(s):
            l=l+chr(s.pop(i))
            if i==0:
                continue
            else:
                i=i-1
        else:
            i=i+1
            if s[i]==min(s):
                l=l+chr(s.pop(i))
                i=i-1
    print(l)
else:
    print("NO")