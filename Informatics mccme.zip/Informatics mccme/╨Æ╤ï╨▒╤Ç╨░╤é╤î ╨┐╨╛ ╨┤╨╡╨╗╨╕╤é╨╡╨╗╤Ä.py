n=int(input())
b=" "
a=list(map(int,input().split()))
p=0
k,m=map(int,input().split())
for i in range(n):
    if (a[i]%k==0 and a[i]%m!=0 and len(str(a[i]))==3):
        p=1
        b=b+str(a[i])+" "
if p==0:
    print(0)
else:
    print(b)
