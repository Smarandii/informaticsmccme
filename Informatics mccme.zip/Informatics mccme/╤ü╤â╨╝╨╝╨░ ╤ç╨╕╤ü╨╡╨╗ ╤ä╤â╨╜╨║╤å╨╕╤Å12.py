# _*_ coding: utf-8 _*_

print(sum(map(int,list(input()))))