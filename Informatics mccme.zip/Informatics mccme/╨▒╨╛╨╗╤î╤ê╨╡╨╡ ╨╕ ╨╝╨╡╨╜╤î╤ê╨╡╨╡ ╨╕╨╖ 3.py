a,b,c=map(int,input().split())
 
f=a
g=b
if g>a:
    g=a
if g>c:
    g=c
print(g)
if f<b:
    f=b
if f<c:
    f=c
print(f)
