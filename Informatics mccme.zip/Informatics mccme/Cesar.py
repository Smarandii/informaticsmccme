alpha="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
n=str(input()).upper()
k=int(input())
sdvig=n[:-k:]
print(sdvig,n)