k=int(input())
if k>=1 and k<=100000:
    n=k%2
if n>0:
    print("NO")
m=k//2    
if m%2>0:
    print("NO")
else:
    print("YES")