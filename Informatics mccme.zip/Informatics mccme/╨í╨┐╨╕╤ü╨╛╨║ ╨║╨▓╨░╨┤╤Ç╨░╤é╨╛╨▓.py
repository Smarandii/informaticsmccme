n=int(input())
k=0
while n>k**2:
    k=k+1
    if k**2<=n:
        print(k**2, sep=" ")
    
