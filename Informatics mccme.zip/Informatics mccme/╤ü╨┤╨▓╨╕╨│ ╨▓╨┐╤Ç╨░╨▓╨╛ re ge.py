n=int(input())
a=list(map(int,input().split()))
re,ge=map(int,input().split())
sdv=int(input())
sdvig=[]
k=len(a)-1

for i in range(re+1,ge):
    sdvig.append(a[i])

rep=re+1
gep=ge-1
while rep<=gep:
    a.pop(rep)
    gep=gep-1
    
x=re+len(sdvig)+sdv
if x>k:
    i=x-k
elif k>x:
    i=(ge-re)+sdv
elif k==x:
    i=0
    
    
for j in sdvig:
    a.insert(i,j)
    i=i+1
    
for i in a:
    print(i,end=" ")

    