a=0
n=int(input())
def summ(n):
    global a
    a=a+n
    if n!=0:
        n=int(input())
        summ(n)
    else:
        print(a)
summ(n)
