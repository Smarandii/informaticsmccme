a=str(input())
s=[]
if a.isalpha()==False:
    for i in a:
        if i in "0123456789":
            if a.count(i)>1 and (i in s) == False:
                s.append(i)
    s.sort()
    for i in s:
        print(i,end="")
    if s==[]:
        print("NO")
else:
    print("NO")