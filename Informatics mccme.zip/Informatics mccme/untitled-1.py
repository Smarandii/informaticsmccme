m=0
a=list(int(input()).split())
