a,b=map(int, input().split())
n=a
while n**2<=b**2:
    print(n,'*',n,'=',n**2, sep='')
    n=n+1