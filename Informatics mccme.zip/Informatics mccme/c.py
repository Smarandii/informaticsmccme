n=int(input())
k=int(input())
def c(c,k):
    return c(n-1,k-1)+c(k,n-1)
print(c(n,k))