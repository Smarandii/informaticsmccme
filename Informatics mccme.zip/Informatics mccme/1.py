a=int(input())
b=int(input())
v=int(input())
z=a+b+v
print(z)
x=a*b*v
print(x)
n=(a+b+v)/3
print("%.3f" % n)