a=list(map(int,input().split()))
print(max(a),a.index(max(a)))