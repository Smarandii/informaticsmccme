n=int(input())
k=0
p=0
a=list(map(int,input().split()))
for i in range(1,len(a),2):
        if len(a)%2==0:
                b=a[i]
                del a[i]
                a.insert(i, a[i-1])
                del a[i-1]
                a.insert(i-1, b)
        elif len(a)%2!=0:
                p=a[-1]
                del a[-1]
                b=a[i]
                del a[i]
                a.insert(i, a[i-1])
                del a[i-1]
                a.insert(i-1, b)
if p!=0:
        a.append(p)
        for i in range(0,len(a)):
                print(a[i], end=" ")
else:
        for i in range(0,len(a)):
                print(a[i], end=" ")        

        
        