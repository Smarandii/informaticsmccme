a,b=map(int,input().split())
c,d=map(int,input().split())
e=10000
f=0
while e>9999 and e<100000:
    if e%a==b and e%c==d:
        print(e)
        f=1
    e=e+1
if f==0:
    print(-1)