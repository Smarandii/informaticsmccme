a=list(map(int,input().split()))
b=0
for i in range(len(a)):
    if a.count(a[i])>b:
        b=a.count(a[i])
        b1=a[i]
print(b1)
