n=int(input())
m=10**n
m1=m//10
for i in range(m,m1-1,-1):
        if i%2!=0:
                print(i,end=" ")
