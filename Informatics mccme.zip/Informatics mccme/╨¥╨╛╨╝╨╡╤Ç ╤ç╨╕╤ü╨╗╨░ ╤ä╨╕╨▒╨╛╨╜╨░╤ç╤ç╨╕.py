x=int(input())
p=int(input())
y=int(input())
k=0
while x<y:
    p=p/100
    x1=x*p
    x=x+x1
    round(x)
    k=k+1
    print(p, x1, x, k)
    continue

