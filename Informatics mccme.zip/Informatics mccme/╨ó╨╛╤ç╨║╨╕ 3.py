x,y=map(float,input().split())

import math

o=True

if y>2-x*x:
    o=False
if y<x:
    o=False
if y<0 or x>0 or (x==0 and y==0):
    o=False
if x>0 and y>0 and y<2-x*x:
    o=True
if x<0 and y<0 and y<2-x*x and x<y:
    o=True
if x<0 and y>0 and y<2-x*x:
    o=True
if o:
    print("YES")
else:
    print("NO")