a=float(input())
n=int(input())
global k
def power(a,n):
    if a==0: 
        return 0
    elif n>0:
        if n!=0:    
            a=a*k
            n=n-1
            return power(a,n)
        else:
            return a
    else:
        if n!=0:
            a=a*k
            n=n+1
            return power(a,n)
        else:
            return a
if n==0:
    print(1)
elif n>0:
    n=n-1
    k=a
    print(power(a,n))
elif n<0:
    k=1/a
    n=n-1
    print(power(a,n))

