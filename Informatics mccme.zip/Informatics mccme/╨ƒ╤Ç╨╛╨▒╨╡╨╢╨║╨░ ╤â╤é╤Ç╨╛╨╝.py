x=int(input())
y=int(input())
k=0
k1=0
while x<y:
    k=k+1
    k1=x*0.1
    x=x+k1
print(k+1)
    
