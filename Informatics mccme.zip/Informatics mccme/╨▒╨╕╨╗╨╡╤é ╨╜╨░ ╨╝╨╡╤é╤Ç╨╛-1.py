a=int(input())
l==0
k==0
m==0
if a<10:
    v=a*1
    if v*15<125:
        l=v
elif a>=10 and a<60:
    v=a%10
    u=a//10
    if v==0:
        k==u        
        print(l, k, m)
    elif v>0 and v<10:
        u=a//10
        k==u
        j=abs(v-a)
        j=l
        if j<10:
            v=j*1
            if v*15<125:
                l=v
                print(l, k, m)
                
    if v*125<440:
        k=v
elif a>=60:
    v=a%60
    if v<10:
        l=v*1
    elif v>=10 and v<60:
        v=a//10
        if v*125<440:        
            m==v
          