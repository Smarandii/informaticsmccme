a=list(map(int,input().split()))
m=[]
for i in range(len(a)):
    if a.count(a[i])==1:
        b=a[i]
        m.append(b)
for i in range(len(m)):
    print(m[i], end=" ")
