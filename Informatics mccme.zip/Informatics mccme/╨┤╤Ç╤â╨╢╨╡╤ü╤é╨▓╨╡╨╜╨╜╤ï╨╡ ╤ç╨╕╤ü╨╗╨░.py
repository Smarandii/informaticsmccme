n,n1=map(int,input().split())
def summ(n):
    s=0
    for i in range(1,n):
        if n%i==0:
            s=s+i
    return s
if summ(n)==n1 and summ(n1)==n:
    print("YES")
else:
    print("NO")
    