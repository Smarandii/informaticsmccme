n=int(input())
for i in range(100,1000):
    c1=i%10
    c2=i//10
    c3=c2//10
    c4=c2%10
    if c1+c3+c4==n:
        print(i)