def c(n,k):
     def factor(x):
          global fac
          global i
          if i<x:
               i += 1
               fac=fac*i
               return factor(x)
          else:
               fac1=fac
               fac=1
               i=0
               return fac1
     return (factor(n)/(factor(k)*factor(n-k)))
n=int(input())
k=int(input())
fac=1 
i=0
print(round(c(n,k)))