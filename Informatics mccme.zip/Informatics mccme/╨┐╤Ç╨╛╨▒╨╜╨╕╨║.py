a=map(input,input().split())
print(a)