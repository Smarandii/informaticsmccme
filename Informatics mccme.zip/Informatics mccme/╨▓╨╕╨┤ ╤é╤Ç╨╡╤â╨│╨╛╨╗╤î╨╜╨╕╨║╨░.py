a=int(input())
b=int(input())
c=int(input())
if (a+b>c and a+c>b and b+c>a) and (a+b!=c or a+c!=b or b+c!=a) or (c**2==b**2+a**2 or b**2==a**2+c**2 or a**2==b**2+c**2):
    print("rectangular")
elif (a+b>c and a+c>b and b+c>a) and (a+b!=c or a+c!=b or b+c!=a) and (c**2<b**2+a**2 or b**2<a**2+c**2 or a**2<b**2+c**2):
    print("acute")
elif (a+b>c and a+c>b and b+c>a) and (a+b!=c or a+c!=b or b+c!=a) and (c**2>b**2+a**2 or b**2>a**2+c**2 or a**2>b**2+c**2):
    print("obtuse")
else:
    print("impossible")   