a=int(input())
b=int(input())
while a and b:
    if a>b:
        a=a%b
    else:
        b=b%a
print(a+b)