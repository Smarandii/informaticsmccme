exp=str(input()).split()
def main(exp):
    stack=[]
    for i in exp:
        if i!="+" and i!="-" and i!="*":
            stack.append(int(i))
        else:
            operand2 = stack.pop()
            operand1 = stack.pop()
            result = doMath(i,operand1,operand2)
            stack.append(result)
    return stack.pop()

def doMath(op, op1, op2):
    if op == "*":
        return op1 * op2
    elif op == "+":
        return op1 + op2
    else:
        return op1 - op2

print(main(exp))
