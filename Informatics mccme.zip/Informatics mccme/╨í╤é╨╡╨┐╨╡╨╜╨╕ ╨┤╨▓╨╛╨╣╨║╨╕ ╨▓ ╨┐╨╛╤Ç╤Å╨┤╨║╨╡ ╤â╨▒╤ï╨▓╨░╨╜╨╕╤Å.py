n=int(input())
l=[]
for i in range(2,n,2):
    l.append(pow(2,i))
l.reverse()
if l:
    print(*l)
else:
    print(0)
