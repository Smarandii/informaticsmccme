a=int(input())
s=1
k=0
for i in range(0,100):
    if s>=a:
        print(k)
        break
    s=s*2
    k=k+1