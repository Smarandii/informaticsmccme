import random
a,b,n=map(int,input().split())
m=[]
l=0
s=0.000
s1=0.000
l1=0
while n:
    m.append(random.randrange(a,b))
    n=n-1
for i in range(len(m)):
    print(m[i], end=" ")
    if m[i]<50:
        s=s+float(m[i])
        l=l+1
    else:
        s1=s1+float(m[i])
        l1=l1+1
if l1==0:
    print()
    print('%.3f'%(s/l),'%.3f'%0.000)
if l==0:
    print()
    print('%.3f'%0.000,'%.3f'%(s1/l1))
if (l and l1) and (s and s1):
    print()
    print(('%.3f'%(s/l)),('%.3f'%(s1/l1)))
