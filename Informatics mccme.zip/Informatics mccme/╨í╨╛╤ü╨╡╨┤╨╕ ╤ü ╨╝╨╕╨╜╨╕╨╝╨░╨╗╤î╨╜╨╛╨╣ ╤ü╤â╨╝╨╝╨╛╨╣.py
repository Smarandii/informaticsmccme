import random
a,b,n=map(int,input().split())
m=[]
while n:
    m.append(random.randrange(a,b+1))
    n=n-1
s=max(m)+max(m)
for i in range(len(m)):
    print(m[i],end=" ")
for i in range(len(m)-1):
    if m[i]+m[i+1]<=s:
        s=m[i]+m[i+1]
        k=i
        k1=i+1
print()
print(k+1,k1+1)
