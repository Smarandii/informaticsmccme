n,m=map(int,input().split(" "))
a=[]
for i in range(n):
    a.append(list(map(str,input().split())))
k=int(input())
r=int(input())
num=0
p=0
for i in a:
    for j in i:
        if len(j)==k:
            for l in range(len(j)):
                num=int(j[l])+num
            if num%r==0:
                p=p+1
            num=0
print(p)