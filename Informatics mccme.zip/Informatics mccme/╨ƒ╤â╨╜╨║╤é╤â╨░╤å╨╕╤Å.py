a=str(input())
k=0
for i in a:
    if i in  ".,;:!?":
        k=k+1
print(k)