l=0
k=0
a=1
while a!=0:
    a=int(input())
    l=a+l
    k=k+1
print(l/(k-1))