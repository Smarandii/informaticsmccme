a,b=map(float, input().split())
c,d=map(float, input().split())
x=round(((a-c)**2+(b-d)**2)**0.5, 3)
print(x)