N=int(input())
M=int(input())
x=int(input())
y=int(input())
if N>M:
    t=N;N=M;M=t
if x>N//2:
    x=N-x
if y>M//2:
    y=M-y
if x>y:
    print(y)
elif y>x:
    print(x)