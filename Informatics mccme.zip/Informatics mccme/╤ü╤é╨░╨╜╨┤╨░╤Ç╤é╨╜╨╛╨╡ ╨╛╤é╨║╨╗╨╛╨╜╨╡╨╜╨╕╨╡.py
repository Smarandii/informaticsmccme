x=1
s=0
n=0
k=0
q=[]
while x:
    x=int(input())
    q.append(x)
    n=n+1
    s=s+x
s=s/(n-1)
for i in range(len(q)-1):
    k=k+(q[i]-s)**2
k=(k/(n-2))**0.5
print(k)