a=int(input())
if a==11 or a>=5 and a<=20:
    print(a, "korov")
elif a%10==1:
    print (a,'korova')
elif a%10==2 or a%10==3 or a%10==4:
    print (a,'korovy')
elif a%10==5 or a%10==6 or a%10==7 or a%10==8 or a%10==9 or a%10==0:
    print (a,'korov')
