n=int(input())
l=bin(n)[2::]
for i in range(len(l)):
    if l[i]=="1":
        p=len(l)-(i+1)
        break

l=[]
for i in range(2,p+1,2):
    l.append(pow(2,i))
l.reverse()
if l:
    print(*l)
else:
    print(0)
    