n=int(input())
a=list(map(int, input().split()))
n1,n2=map(int,input().split())
a1=[]
a2=[]
a3=[]
a1.append(a[n1-1:n2])
for i in range(n2-n1,-1,-1):
    a2.append(a1[0][i])
for i in range(len(a)):
    if i<n1-1 or i>n2-1:
        a3.append(a[i])
    elif i>=n1-1 and i<=n2-1:
        a3.append(a2[i-n1+1])
for i in range(len(a3)):
    print(a3[i], end=" ")

    
