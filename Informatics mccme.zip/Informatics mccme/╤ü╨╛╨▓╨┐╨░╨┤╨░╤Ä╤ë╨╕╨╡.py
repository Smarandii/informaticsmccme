a=int(input())
b=int(input())
c=int(input())
v=(a+b+c)//3
if a!=b!=c and a!=c and b!=c and b!=a:
    print(0)
elif v*3==a+b+c:
    print(3)    
elif c==a or a==b or c==b:
    print(2)
