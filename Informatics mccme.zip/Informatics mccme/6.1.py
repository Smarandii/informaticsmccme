a=float(input())
b=float(input())
n=(a**b)
print(round(n,3))