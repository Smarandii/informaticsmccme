n=int(input())
k=0
a=list(map(int,input().split()))
for i in range(1,len(a)-1):
    if a[i+1]<a[i] and a[i-1]<a[i]:
        k=k+1
print(k)
        
        