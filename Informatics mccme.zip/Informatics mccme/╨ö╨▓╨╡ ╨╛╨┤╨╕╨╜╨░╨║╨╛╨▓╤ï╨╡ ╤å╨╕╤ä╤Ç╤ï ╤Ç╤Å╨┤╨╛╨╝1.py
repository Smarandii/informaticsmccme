a=int(input())
a1=0
k=0
s=1
s1=0
o=0
while a>0:
    o=s
    s1=a%10
    a=a//10    
    s=a%10
    if s1==s and s1!=o:
        k=k+1
if k==1 or k==2:
    print("YES")
else:
    print("NO")
