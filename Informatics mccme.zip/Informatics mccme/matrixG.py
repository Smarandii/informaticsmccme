n=int(input())
a=[]
for i in range(n):
    a.append(list(map(int,input().split())))

for i in range(len(a)):
    for j in range(len(a[i])):
        if j>(0+i):
            del a[i][j]
            a[i].insert(j,0)
for i in a:
    for j in i:
        print(j,end=" ")
    print()