a,b=map(int,input().split())
mass=[]
dl=0
e=0
for i in range(a,b+1):
    print(i**2, end=' ')