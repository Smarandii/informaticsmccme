n=int(input())
k=n
a=[]
while n:
    a.append(list(map(str,input().split())))
    n-=1
for i in range(k):
    for j in range(k):
        if a[i][j].isdigit():
            if len(" "+a[i][j])!=3:
                a[i][j]=" "+a[i][j]
        
for i in range(len(a)):
    k=i
    while k>0:
        a[i].pop()
        k=k-1
for i in a:
    print(*i)