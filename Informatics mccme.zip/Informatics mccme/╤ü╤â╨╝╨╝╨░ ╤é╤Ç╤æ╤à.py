n=int(input())
k=0
if n%3==0:
    for i in range(1,n):
        for j in range(1,n):
            for q in range(1,n):
                if i+j+q==n and i<=j<=q:
                    k=k+1
if n%3!=0:
    for i in range(1,n):
        for j in range(2,n):
            for q in range(3,n):
                if i+j+q==n:
                    k=k+1
print(k)
