a=list(map(int,input().split()))
k=0
for i in range(0,len(a)):
    for j in range(0,len(a)):
        if a[i]==a[j]:
            k=a[j]
    if a[j]==a[i]:
        print('YES')
    else:
        print('NO')
        