n=int(input())
if n>=1:
    s=((1+n)/2)*n
    print(int(s))