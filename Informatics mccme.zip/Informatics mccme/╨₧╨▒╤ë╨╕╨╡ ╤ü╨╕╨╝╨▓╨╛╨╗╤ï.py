a=str(input())
b=str(input())
s=[]
m=""
lk=min(len(a),len(b))
if lk==len(a):
    k=a
    k1=b
else:
    k=b
    k1=a
for i in k:
    if (i in k1) and (ord(i) in s) == False:
        s.append(ord(i))
if s:
    s.sort()
    for i in s:
        m=m+chr(i)
    print(m)
else:
    print("NO")