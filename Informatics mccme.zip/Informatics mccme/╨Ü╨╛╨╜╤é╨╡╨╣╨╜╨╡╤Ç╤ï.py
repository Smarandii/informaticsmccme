n=int(input())
sklad=[]
while n:
    stpk=list(input().split(" "))
    sklad.append(stpk)
    n=n-1
for i in range(len(sklad)):
    for j in range(len(sklad[i])):
        if j==0 and sklad[i][j]==0:
            break
print(sklad)