x,y=map(float,input().split())

import math

o=False

if y<1 and x<1 and x*x+y*y>1:
    o=True
if x*x+y*y<1:
    o=True
if o:
    print("YES")
else:
    print("NO")