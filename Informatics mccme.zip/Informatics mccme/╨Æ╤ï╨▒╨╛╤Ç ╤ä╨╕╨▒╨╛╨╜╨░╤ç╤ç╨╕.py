def fib(n):
    a=b=1
    while b<n:
        c=a+b
        a=b
        b=c
    if b==n:
        return True
    else:
        return False

n=int(input())
b=""
a=list(map(int,input().split()))
fib(max(a))
for i in range(n):
    if fib(a[i]):
        b=b+str(a[i])+" "        
if b:
    print(b)
if b=="":
    print(0)