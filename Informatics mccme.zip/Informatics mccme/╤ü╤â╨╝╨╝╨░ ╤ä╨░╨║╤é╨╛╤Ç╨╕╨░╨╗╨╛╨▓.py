l=int(input())
s=0
for n in range(1,l+1): 
     f=1 
     i=0 
     while i<n:
          i+= 1
          f=f*i 
     s=s+f
print(s)
