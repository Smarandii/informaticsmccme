exp=str(input()).split()
def delete(i):
    if exp[i]!="+" and exp[i]!="-" and exp[i]!="*":
        i=i+1
        return i
    
    elif exp[i]=="+":
        k=int(exp[i-2])+int(exp[i-1])
        del exp[i]
        del exp[i-1]
        del exp[i-2]
        i=i-2
        exp.insert(i,k)
        return i   
    
    elif exp[i]=="-":
        k=int(exp[i-2])-int(exp[i-1])
        del exp[i]
        del exp[i-1]
        del exp[i-2]
        i=i-2
        exp.insert(i,k)
        return i        
    
    elif exp[i]=="*":
        k=int(exp[i-2])*int(exp[i-1])
        del exp[i]
        del exp[i-1]
        del exp[i-2]
        i=i-2
        exp.insert(i,k)
        return i        
    
i=0
while len(exp)!=1:
    i=delete(i)

print(exp[0])
