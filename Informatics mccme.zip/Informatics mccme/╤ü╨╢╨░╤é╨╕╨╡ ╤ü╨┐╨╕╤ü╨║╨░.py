a=list(map(int,input().split()))
b=len(a)
k=a.count(0)
for i in range(b):
        if k>0:
                a.remove(0)
                a.append(0)
                k=k-1
        print(a[i], end=" ")
