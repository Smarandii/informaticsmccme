def qwer():
    a=int(input())
    if a != 0:
        qwer()
    print(a)
qwer()
