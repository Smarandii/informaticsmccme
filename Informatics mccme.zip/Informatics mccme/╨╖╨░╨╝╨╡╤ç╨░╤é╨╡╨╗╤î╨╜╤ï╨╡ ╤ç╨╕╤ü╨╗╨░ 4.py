a=int(input())
b=int(input())
for i in range(a,b):
    c=i
    c1=i%10
    c1=str(c1)
    i=i//10
    c2=i%10
    c2=str(c2)
    i=i//10
    c3=c//10
    c3=str(c3)
    c3=c3[:-1:]
    cd=c1+c2    
    cd=int(cd)
    c3=int(c3)
    if cd==c3:
        print(c)