ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
text=str(input())
step=int(input())
def decode(text, step):
    return text.translate(str.maketrans(ALPHA[step:] + ALPHA[:step], ALPHA))
print(decode(text,step))