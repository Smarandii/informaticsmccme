import random
a,b,n=map(int,input().split())
m=[]
k=0
k1=0
s12=-1
while n:
    m.append(random.randrange(a,b+1))
    n=n-1
s=max(m)-min(m)

for i in range(len(m)):
    print(m[i],end=" ")
for i in range(len(m)):
    for j in range(len(m),1,-1):
        if i==j:
            pass
        else:
            s1=abs(m[i]-m[j])
            if s12!=s1:
                if s1<s:
                    s=s1
                    s12=s
                    k=i
                    k1=j
print()
print(k+1,k1+1)
