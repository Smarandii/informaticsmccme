n=int(input())
b=""
a=list(map(str,input().split()))
m=set(a)
m=list(m)
for i in range(len(m)):
    if a.count(m[i])>1 and m[i] not in b:
        b=b+m[i]+" "        
        print(a[a.index(m[i])],end=" ")
if b=="":
    print(0)