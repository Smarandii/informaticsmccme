a=list(map(int,input().split()))
k1=0
k=0
for i in range(1,len(a)):
    if (a[i]>0 and a[i-1]>0) or (a[i]<0 and a[i-1]<0):
        k=a[i]
        k1=a[i-1]
        break
print(k1,k)