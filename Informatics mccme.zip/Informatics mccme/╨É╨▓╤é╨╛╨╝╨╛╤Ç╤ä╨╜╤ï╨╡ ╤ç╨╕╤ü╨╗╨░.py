a,b=map(int,input().split())
i=0
d=0
k=0
for i in range((a-1),(b+1)):
    d=10
    while d<=i:
        d=d*10
        if i*i%d==i:
            print(i, end=" ")
            k=True
if k!=True:
    print(-1)