a,b=map(int,input().split())
n=0
while a!=0 and b!=0:
    n=n+1
    if a > b:
        a = a % b
    else:
        b = b % a
 
print (a+b, n)