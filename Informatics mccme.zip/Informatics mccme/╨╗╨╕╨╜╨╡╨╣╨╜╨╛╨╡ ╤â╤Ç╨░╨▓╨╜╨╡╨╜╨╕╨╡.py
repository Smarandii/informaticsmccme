a=int(input())
b=int(input())
if a==0 and b==0:
    print("INF")  
elif a!=0:
    d=b%a
    if d>0 or d<0:
        print("NO")    
    elif d==0:
        x=-b//a
        if a==0:
            print("NO")
        else:
            print(x)
elif a==0:
    print("NO")
    