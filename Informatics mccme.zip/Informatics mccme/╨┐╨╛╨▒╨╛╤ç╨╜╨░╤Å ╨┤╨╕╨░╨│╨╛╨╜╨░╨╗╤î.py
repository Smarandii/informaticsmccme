n=int(input())
a=[]
for i in range(n):
    a.append([])
    for j in range(n):
        if i+j==n-1 :
            a[i].append(1)
        elif j+i>n-1:
            a[i].append(2)
        else:
            a[i].append(0)
for i in a:
    for j in i:
        print(j, end=" ")
    print( )