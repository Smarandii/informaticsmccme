n=4
for i in range(n):
    o=int(input()).split(" ")
    if o>=m:                       
        a.append(o)
        m=o     
    else:
        print("x1>x0, y1>y0")
print(a)