n, m =(map(int, input().split())) 
a = [] 
for i in range(n): 
    a.append(list(map(int, input().split()))) 
maxim=0 
x=0 
y=0 
for i in range(n): 
    for q in range(m): 
        if a[i][q]>maxim: 
            maxim=a[i][q] 
            x=i 
            y=q 
print(maxim) 
print(x, y)