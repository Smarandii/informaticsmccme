n=int(input())
k=0
a=list(map(int,input().split()))
for i in range(0,len(a)):
    if a[i]>0:
        k=k+1
print(k)
        