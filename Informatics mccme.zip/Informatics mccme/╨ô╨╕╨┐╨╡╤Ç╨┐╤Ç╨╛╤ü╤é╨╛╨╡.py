def IsPrime(n):
   d=2
   while n%d!=0:
      d+=1
   return d==n


n=int(input())
if n==1:
   print("NO")
else:
   if len(str(n))>2:
      k=str(n)
      n1=int(k[0:-1])
      n2=int(k[0:-2])
      if n1==1 or n2==1:
         print("NO")
      else:
         if IsPrime(n) and IsPrime(n1) and IsPrime(n2):
            print("YES")
         else:
            print("NO")
   elif IsPrime(n) and len(str(n))==1:
      print("YES")
   else:
      k=str(n)
      n1=int(k[0:-1])
      if n1==1:
         print("NO")
      else:
         if IsPrime(n) and IsPrime(n1):
            print("YES")
         else:
            print("NO")
          