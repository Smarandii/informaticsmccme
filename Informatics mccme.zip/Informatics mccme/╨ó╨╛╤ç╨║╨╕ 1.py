x,y=map(float,input().split())
o=True
if x*x+y*y<=4:
    o=False
if x==y or y>x:
    o=False
if x>2:
    o=False
if y<=0:
    o=False
if o:
    print("YES")
else:
    print("NO")