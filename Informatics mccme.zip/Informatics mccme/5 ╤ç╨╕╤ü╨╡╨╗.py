a,b,c,d,e=map(int,input().split())

f=a
g=b
if g>a:
    g=a
if g>c:
    g=c
if g>d:
    g=d
if g>e:
    g=e
print(g)
if f<b:
    f=b
if f<c:
    f=c
if f<d:
    f=d
if f<e:
    f=e
print(f)