a=int(input())
b=int(input())
def summ(a,b):
    if a==0 and b==0:
        print(0)
    elif a==0 and b:
        print(b)
    elif b==0 and a:
        print(a)
    else:
        b=b-1
        a=a+1
        if b:
            summ(a,b)
        else:
            print(a)
summ(a,b)
