a=str(input())
def palindrom(a):
    b=a[::-1]
    if a==b:
        return 'yes'
    else:
        return 'no'     
print(palindrom(a))
    
