def summcif(i):
    s=0
    k=str(i)
    for j in range(len(k)):
        s=s+int(k[j])
    return s

l,l1=map(int,input().split())
s=0
o=0
for i in range(l,l1+1):
    ds=0
    a=[i*2,i*3,i*4,i*5,i*6,i*7,i*8,i*9]
    k=summcif(i)
    for k1 in range(8):
        if summcif(a[k1])==k:
            o=1
        else:
            o=0
            ds=1
    if o==1 and ds!=1:
        print(i, end=" ")