n=int(input())
line=[] 
for i in range(n):
    com=str(input())
    if com=="-":
        print(line[0])
        del line[0]
    else:
        option,ind=com.split(" ")
        if option=="+":
            line.append(ind)
        elif option=="*":
            if len(line)%2==0:
                line.insert(len(line)//2,ind)
            else:
                line.insert(len(line)//2+1,ind)