x=int(input())
p=int(input())
y=int(input())
p=p/100
k=0
while x<y:
    x1=x*p
    x=x1+x
    k=k+1
    x=round(0)
    print(x, k)