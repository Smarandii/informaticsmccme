a=list(map(int,input().split())) 
k=0 
b=0 
for i in range(len(a)): 
    for j in range(b,len(a)): 
        if i==j: 
            continue 
        if a[i]==a[j]: 
            k=k+1 
    b=b+1 
print(k)