a=str(input())
s=[]
for i in a:
    if i in "0123456789" and (i in s) == False:
        s.append(i)
if s:
    s.sort()
    for i in s:
        print(i,end="")
else:
    print("NO")