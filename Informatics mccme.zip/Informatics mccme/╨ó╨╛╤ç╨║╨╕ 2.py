x,y=map(float,input().split())

import math

o=True

if y>math.sin(x):
    o=False
if y>=0.5:
    o=False
if y<=0:
    o=False
if x<=0:
    o=False
if x>=math.pi:
    o=False
    
if o:
    print("YES")
else:
    print("NO")