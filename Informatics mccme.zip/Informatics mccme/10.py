a=[]
x=8
while x:
    a.append(list(map(str,input().split())))
    x-=1
for i in range(8):
    for j in range(8):
        if a[i][j]=="R":
            a[i]=[0,0,0,0,0,0,0,0]
            a[0][j]=0
            a[1][j]=0
            a[2][j]=0
            a[3][j]=0
            a[4][j]=0
            a[5][j]=0
            a[6][j]=0
            a[7][j]=0
            a[i][j]=="R"
            
        if a[i][j]=="B":
            a[i][j]==0
            if i==0:
                for l in range(8-j):
                    a[i+l][j+l]
                for l in range(j+1):
                    a[i+l][j-l]
                 