n = int(input())
m = 1
k = 0
while m<n:
    m=m*2
    k=k+1
print(k)