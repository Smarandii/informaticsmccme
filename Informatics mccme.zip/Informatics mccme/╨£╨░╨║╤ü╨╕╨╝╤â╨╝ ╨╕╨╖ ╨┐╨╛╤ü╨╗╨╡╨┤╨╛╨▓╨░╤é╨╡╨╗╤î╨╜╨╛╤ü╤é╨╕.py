s=0
a=1
while a!=0: 
    if a>s:
        s=a
    elif a==s:
        s=a
    elif s>a:
        s=s
    a=int(input())
print(s)
    
