a=str(input())
alpha=""
k=0
for i in range(len(a)):
    if a[i]==" ":
        if k==0:
            alpha=alpha+" "
            k=1
    if a[i]!=" ":
        k=0
        alpha=alpha+a[i]
print(alpha)


    