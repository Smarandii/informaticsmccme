def chocolate(n, m, k):
    if k < n * m and (k % n == 0 or k % m == 0):
        return True
    return False
 
data = [[4, 2, 6], [2, 10, 7], [5, 7, 1], [7, 4, 21], [5, 12, 100],
        [6, 6, 6], [6, 6, 35], [6, 6, 37], [7, 1, 99], [300, 100, 3000],
        [256, 124, 4069], [348, 41, 6183]]
 
for values in data:
    print(values, chocolate(*values))