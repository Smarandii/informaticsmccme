a=list(map(int,input().split()))
b=list(map(int,input().split()))
k=0
y=0
a=set(a)
b=set(b)
a=list(a.intersection(b))
l=[]
for i in range(0,len(a)):
    if a[i]>k:
        k=a[i]
        y=y+1
        if y==len(a):
            l.append(k)
        l.append(k)
    elif a[i]<k:
        l.insert(0,a[i])
l=set(l)
l=list(l)
for i in range(0,len(l)):
    print(a[i], end=" ")