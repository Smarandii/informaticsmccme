n=int(input())
a=list(map(int,input().split()))
l=list
for i in range(0,len(a)):
    if a[0]==a[1]:
        u=list(a[1])
        l.append(u)
        
    if a[i-1]+a[i+1]==a[i]:
        u=list(a[i])
        l.append(u)
    if a[-1]==a[-2]:
        u=list(a[-1])
        l.append(u)
print(l)
        