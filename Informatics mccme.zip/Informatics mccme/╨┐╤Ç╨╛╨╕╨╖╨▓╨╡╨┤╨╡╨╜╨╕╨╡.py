m,n=map(int,input().split())
a=0
for x in range ((abs(n))):
    a=a+m
if n<0:
    print(-a)
else:
    print(a)