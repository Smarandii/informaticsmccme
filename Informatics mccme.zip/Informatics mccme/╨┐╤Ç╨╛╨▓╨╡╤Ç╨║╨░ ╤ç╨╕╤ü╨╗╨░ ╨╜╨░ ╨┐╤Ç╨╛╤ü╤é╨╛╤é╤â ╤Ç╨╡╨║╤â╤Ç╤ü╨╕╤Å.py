import sys
d=2
sys.setrecursionlimit(10000000)
def IsPrime(n):
    global d
    if d*d<=n and n%d!=0:
        d=d+1
        return IsPrime(n)
    elif d*d>n:
        return "YES"
    else:
        return "NO"


x=int(input())
print(IsPrime(x))