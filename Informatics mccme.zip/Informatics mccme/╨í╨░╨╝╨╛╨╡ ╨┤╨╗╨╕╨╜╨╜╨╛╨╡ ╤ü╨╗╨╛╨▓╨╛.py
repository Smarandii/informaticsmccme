s=input()
s1=""
a=[]
w=[]
s=s.rstrip()
for i in s:
    if " "==i or "\n"==i or '\f'==i or '\r'==i or '\t'==i or '\v'==i:
        if s1=="":
            continue
        elif s1:
            a.append(len(s1))
            w.append(s1)
            s1=""
            continue
    s1=s1+i
a.append(len(s1))
w.append(s1)
print(w[a.index(max(a))])
print(max(a))