a=int(input())
while a>1:
    if a%2==1:
        break
    a=a//2
if a==1:
    print("YES")
else:
    print("NO")