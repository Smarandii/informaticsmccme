a=list(map(int,input().split()))
for i in range(len(a)-1,-1,-1):
    print(a[i], end=" ")

