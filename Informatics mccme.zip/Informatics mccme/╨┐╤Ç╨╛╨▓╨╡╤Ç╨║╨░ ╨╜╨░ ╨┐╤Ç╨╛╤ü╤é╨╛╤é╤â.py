a=int(input())
j=0
o=0
for i in range(1,a):
    k=a//i
    if a%i==0:
        if k==a or k==1:
            j=j+1
        else:
            o=o+1
if o!=0:
    print("NO")
else:
    print("YES")