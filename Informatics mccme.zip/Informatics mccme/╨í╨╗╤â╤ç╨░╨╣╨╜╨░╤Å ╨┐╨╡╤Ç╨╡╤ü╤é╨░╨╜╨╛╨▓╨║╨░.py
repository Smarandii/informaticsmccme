import random
a=[]
n=int(input())
for i in range(1,n+1):
    a.append(i)
random.shuffle(a)
for i in range(len(a)):
    print(a[i],end=" ")