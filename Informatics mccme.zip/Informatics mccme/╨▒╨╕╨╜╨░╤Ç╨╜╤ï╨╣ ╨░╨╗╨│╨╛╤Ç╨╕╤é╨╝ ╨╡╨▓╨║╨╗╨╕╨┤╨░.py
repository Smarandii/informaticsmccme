def is_odd (n):
    return (n & 1) == 1

def gcd (a, b):
    if a == 0:
        return b                            
    elif b == 0:
        return a                            
    elif a == b:
        return a                            
    elif a == 1 or b == 1:
        return 1                            
    elif is_odd(a):                         
        if is_odd(b):                     
            return gcd(b, abs(a - b))      
        else:                               
            return gcd(a, b >> 1)         
    else:                                
        if is_odd(b):                      
            return gcd(a >> 1, b)          
        else:                        
            return gcd(a >> 1, b >> 1) << 1 