a=int(input())
s=0
while a:
    k=a%10
    s=k+s
    a=a//10
print(s)

    