a=list(map(int,input().split()))
while len(a):
    if min(a)>0:
        print(min(a))
        break
    elif min(a)<0:
        a.remove(min(a))