import math 
def C(n,k): 
    nf=math.factorial(n) 
    kf=math.factorial(k) 
    rf=math.factorial(n-k) 
    print(nf/(kf*rf)) 
n=int(input()) 
k=int(input()) 
C(n,k)