a=list(map(int,input().split()))
b=a.copy()
b=set(b)
print(len(b))
