o=2
m=0
l=0
k=0
a=1
while a!=0:
    a=int(input())
    if a%2==0:
        i=1
        k=k+1
    elif a%2>0:
        o=2
if o==2 and k<0:
    print(0)
elif i==1 and k>0:
    print(k-1)
