n,k=map(int,input().split())
m=2*n
o=0
while n<m:
    n1=(n*k)/100
    n=n1+n
    o=o+1
print(o)
    
    