n=int(input())
a=list(map(int,input().split()))
b=min(a)
o=max(a)
for i in range(0,len(a)):
    print(i, end=" ")

