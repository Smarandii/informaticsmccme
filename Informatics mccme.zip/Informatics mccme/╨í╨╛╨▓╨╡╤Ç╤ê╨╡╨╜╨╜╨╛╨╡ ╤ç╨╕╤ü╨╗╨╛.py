def summ(n):
    s=0
    for i in range(1,n//2):
        if n%i==0:
            s=s+i
    return s

n=int(input())
if summ(n)==n//2:    
    print("YES")
else:
    print("NO")