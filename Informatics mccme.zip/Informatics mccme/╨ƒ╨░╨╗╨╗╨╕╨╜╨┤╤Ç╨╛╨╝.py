s=input()
s1=""
for i in range(len(s)-1,-1,-1):
    if s[i]==" ":
        s=s[:i:]+s[i+1::]
        continue
    s1=s1+s[i]
if s==s1:
    print("YES")
else:
    print("NO")