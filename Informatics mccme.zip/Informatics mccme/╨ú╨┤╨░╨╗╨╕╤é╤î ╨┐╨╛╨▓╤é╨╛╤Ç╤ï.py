a=str(input())
def proverka(a):
    s=""
    for i in a:
        if i not in s:
            s=s+i
        else:
            continue
    return s
print(proverka(a))