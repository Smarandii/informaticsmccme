n,m=map(int,input().split(" "))
a=[]
r=[]
v=[]
max1=0
for i in range(n):
    a.append(list(map(int,input().split())))


for i in range(len(a)):
    a[i].reverse()

for i in a:
    for j in i:
        print(j,end=" ")
    print()
        