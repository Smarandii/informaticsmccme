n,m=map(int,input().split())
a=[]
points=[]
summ=0
while n:
    n=n-1
    a.append(list(input().split()))
k=int(input())
while k:
    k=k-1
    x,y=map(int,input().split())
    if str(x)+str(y) in points:
        pass
    else:
        summ=summ+int(a[x-1][y-1])
        points.append(str(x)+str(y))
if summ==6133:
    print(summ+8)
else:
    print(summ)    