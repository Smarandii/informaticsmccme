n, m =(map(int, input().split())) 
a = [] 
for i in range(n): 
    a.append(list(map(int, input().split()))) 
maxim=0 
summ=0 
x=0 
y=0 
sum2=0 
for i in range(n): 
    for q in range(m): 
        if a[i][q]>maxim: 
            maxim=a[i][q] 
            x=i 
            summ=0 
            for z in range(m): 
                summ=summ+a[i][z] 
        elif a[i][q]==maxim: 
            sum2=0 
            for g in range(m): 
                sum2=sum2+a[i][g] 
            if sum2>summ: 
                x=i 
print(x)