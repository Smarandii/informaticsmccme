# -*- coding: utf-8 -*-
a=[]
sloya=3
b=[]
sloyb=2
c=[]
sloyc=1
d=[]
sloyd=4
n=4
m=0
o1=list(map(int,input().split(" ")))
for i in range(len(o1)):
    if o1[i]>=m:                       
        a.append(o1[i])
        m=o1[i]     
    else:
        print("x1>x0, y1>y0")
        break
m=0
o2=list(map(int,input().split(" ")))
for i in range(len(o1)):
    if o2[i]>=m:                       
        a.append(o2[i])
        m=o2[i]     
    else:
        print("x1>x0, y1>y0")
        break
m=0    
o3=list(map(int,input().split(" ")))
for i in range(len(o1)):
    if o3[i]>=m:                       
        a.append(o3[i])
        m=o3[i]     
    else:
        print("x1>x0, y1>y0")
        break
m=0    
o4=list(map(int,input().split(" ")))
for i in range(len(o1)):
    if o4[i]>=m:                       
        a.append(o4[i])
        m=o4[i]     
    else:
        print("x1>x0, y1>y0")
        break
    
ok=list(map(int,input().split(" ")))

if (ok[0]>=a[0] and ok[1]>=a[1]) and (ok[0]<=a[2] and ok[1]<=a[3]):
    sloya=1
    sloyc=3
    print("1")
elif (ok[0]>=b[0] and ok[1]>=b[1]) and (ok[0]<=b[2] and ok[1]<=b[3]) :
    sloyb=1
    sloyc=2
    print("2")
elif (ok[0]>=c[0] and ok[1]>=c[1]) and (ok[0]<=c[2] and ok[1]<=c[3]) :
    sloyc=1
    print("3")
elif (ok[0]>=d[0] and ok[1]>=d[1]) and (ok[0]<=d[2] and ok[1]<=d[3]):
    sloyd=1
    sloyc=4
    print("4")
else:
    print("Координаты вне окон")


