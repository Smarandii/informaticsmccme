a=int(input())
k=0
a1=a%2
while a//2>0:
    a=a//2
    k=k+1
print(k, a1)