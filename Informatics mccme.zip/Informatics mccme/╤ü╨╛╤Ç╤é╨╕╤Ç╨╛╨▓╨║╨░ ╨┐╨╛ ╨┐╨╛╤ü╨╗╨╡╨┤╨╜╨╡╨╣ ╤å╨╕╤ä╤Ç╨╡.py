n=int(input())
m=list(map(str,input().split()))
m.sort(key = lambda x : x[-1:])
print(*m)