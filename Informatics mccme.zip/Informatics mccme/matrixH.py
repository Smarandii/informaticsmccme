n=int(input())
a=[]
up=[]
dn=[]
for i in range(n):
    a.append(list(map(int,input().split())))

for i in range(len(a)):
    for j in range(len(a[i])):
        if j>i:
            up.append(a[i][j])
        if j<i:
            dn.append(a[i][j])
if sum(up)==sum(dn):
    print("YES")
else:
    print("NO")

