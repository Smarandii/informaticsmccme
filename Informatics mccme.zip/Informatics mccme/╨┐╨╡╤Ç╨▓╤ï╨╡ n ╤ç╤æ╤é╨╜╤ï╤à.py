n=int(input())
a=0
k=0
while k<n:
    a=a+2
    k=k+1
    print(a, end=" ")
    

    