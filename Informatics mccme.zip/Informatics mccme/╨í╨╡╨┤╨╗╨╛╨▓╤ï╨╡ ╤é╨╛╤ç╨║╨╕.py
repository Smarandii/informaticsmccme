n,m=map(int,input().split())
k=n
a=[]
b=[]
max_row=0
while n:
    a.append(list(map(int,input().split())))
    n-=1
i=0
while i<k:
    min_str=min(a[i])
    j=a[i].index(min_str)
    for p in range(k):
        if a[p][j]>max_row:
            max_row=a[p][j]
            row=j
            string=p
    if min_str==max_row:
        b.append([string+1,row+1])
    max_row=0
    i+=1
    
for i in b:
    print(*i)
if b==[]:
    print(0)