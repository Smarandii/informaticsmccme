n=int(input())
a=list(map(int,input().split()))
stack=[]
for i in a:
    if a.count(i)>1 and i not in stack:
        stack.append(i)
if stack:
    print(max(stack))
else:
    print(-1)