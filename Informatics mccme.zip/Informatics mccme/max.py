n=int(input())
a=list(map(int,input().split()))
b=max(a)
k=0
for i in range(0,len(a)):
    if a[i]==b:
        k=k+1
print(k)        
