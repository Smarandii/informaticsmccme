a=int(input())
b=int(input())

def algortm(a,b):
    if b==0:
        return a,1,0
    else:
        p=a%b
        d,x,y=algortm(b,p)
        x=x-y*(a//b)
        return d,y,x
for i in range(len(algortm(a,b))):
    print(algortm(a,b)[i], end=" ")

