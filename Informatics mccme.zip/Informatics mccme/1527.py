b=int(input())
o=0
k=0
while b>o:
    o=o+1
    p=b%o
    if p==0 or o==b or o==1:
        k=k+1
print(k)
        