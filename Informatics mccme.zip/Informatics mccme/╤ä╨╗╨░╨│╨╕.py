n=int(input())
i=0
l=[]
p5=str(i)
p1="+___ "
p2="|"
p21="/ " 
p3="|__\ "  
p4="|    "
p5=str(i)+" "
a=[]
def penguins(n):
    pp1=''
    pp2=''
    pp3=''
    pp4=''
    pp5=''
    pp21=''
    for i in range(n):
        a.append(p1)
        a.append(p2)
        a.append(p21)
        a.append(p3)
        a.append(p4)
    for i in range(n,0,-1):
        p5=str(i)
        pp1=a[0]+pp1
        pp2=a[1]
        pp21=a[2]
        pp5=pp2+p5+" "+pp21+pp5
        pp3=a[3]+pp3
        pp4=a[4]+pp4
    print(pp1)
    print(pp5)
    print(pp3)
    print(pp4)

    
penguins(n)