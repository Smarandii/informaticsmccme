s=0
for i in range(10):
    a=int(input())
    s=a+s
print(s)    