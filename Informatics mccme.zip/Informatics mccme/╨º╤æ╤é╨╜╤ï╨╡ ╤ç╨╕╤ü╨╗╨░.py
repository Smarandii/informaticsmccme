a=int(input())
cc=0
nc=0
while a>0:
    if (a%2)==0:
        cc=cc+1
    a=a//10
print(cc)