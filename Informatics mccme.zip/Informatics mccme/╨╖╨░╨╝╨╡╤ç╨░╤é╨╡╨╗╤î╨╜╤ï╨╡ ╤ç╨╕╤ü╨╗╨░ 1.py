for i in range(10,100):
    c1=i//10
    c2=i%10
    if i==(c1*c2)*2:
        print(i)