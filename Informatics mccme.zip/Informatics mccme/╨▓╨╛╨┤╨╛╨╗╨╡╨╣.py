A=int(input())
B=int(input())
N=int(input())
if N>B and N>A:
    print("Impossible")
else:
    if A==N:
        print(">A")
    elif B==N:
        print(">B")
    