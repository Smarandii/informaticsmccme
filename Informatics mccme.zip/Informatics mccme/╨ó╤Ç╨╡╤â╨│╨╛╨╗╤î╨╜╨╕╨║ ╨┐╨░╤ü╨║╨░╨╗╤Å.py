k=int(input())
a=[[1]*n for n in range(k+1)]
a.pop(0)
for i in range(2,k):
    for j in range(i):
        if j==0:
            continue
        a[i][j]=a[i-1][j]+a[i-1][j-1]
        
for i in a:
    print(*i)