n=int(input())
k=0
a=list(map(int,input().split()))
for i in range(1,len(a)):
    if a[i]>0 and a[i-1]>0 or a[i]<0 and a[i-1]<0:
        k=1
if k==1:
    print("YES")
else:
    print("NO")
        