a=int(input())
c=list(map(int,input().split()))
k=c[0] 
t=c[0]
b=1
d=b
for i in range(1,a):
    if c[i]==t:
        b=b+1
    elif b>d:
        d=b
        b=1
        t=c[i]
        k=c[i-1]
    elif b<=d:
        b=1
        t=c[i]
if b>d:
    d=b
print(k,d)