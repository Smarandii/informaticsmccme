a,n=map(int,input().split())
z=n
b=[]
while n:
    b.append(a)
    a=a+1
    n=n-1

for i in range(z):
    print(b[i], end=" ")