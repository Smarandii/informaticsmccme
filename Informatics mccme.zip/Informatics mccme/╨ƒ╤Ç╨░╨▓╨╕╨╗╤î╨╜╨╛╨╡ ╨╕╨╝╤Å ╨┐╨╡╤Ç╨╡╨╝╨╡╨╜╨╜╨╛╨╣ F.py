a=str(input())
def proverka(a):
    if a[0].isdigit():
        return 'NO'
    for i in a:
        if (ord(i) in range(48,58)) or (ord(i) in range(65,91)) or (ord(i) in range(97,123)) or i=="_":
            continue
        else:
            return "NO"
    return "YES"
print(proverka(a))