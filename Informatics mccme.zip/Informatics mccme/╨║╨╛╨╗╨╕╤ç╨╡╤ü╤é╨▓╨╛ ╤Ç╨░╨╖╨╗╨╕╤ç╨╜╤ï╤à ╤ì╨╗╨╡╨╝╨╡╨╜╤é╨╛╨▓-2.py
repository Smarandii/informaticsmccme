a=set(map(int,input().split()))
print(len(a))