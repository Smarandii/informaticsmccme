a,b=map(float,input().split())
c=a
d=a
if b>0:
    while b!=1:
        c=c*d
        b-=1
elif b<0:
    while b!=-1:
        c=c*d
        b+=1
        c=1/c
else:
    print(1.000)
print("%.3f" % c)   