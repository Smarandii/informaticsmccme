a=int(input())
b=int(input())
c=int(input())
g=b
if g<a:
    g=a
if g<c:
    g=c
if g<b:
    g=b
print(g)