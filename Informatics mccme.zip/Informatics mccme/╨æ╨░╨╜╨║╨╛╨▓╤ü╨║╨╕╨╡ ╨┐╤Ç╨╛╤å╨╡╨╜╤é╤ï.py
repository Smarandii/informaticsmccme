n=int(input())
k=int(input())
m=int(input())
o=0
while n<m:
    n1=n*(k/100)
    n=n1+n
    o=o+1
print(o)
    
    