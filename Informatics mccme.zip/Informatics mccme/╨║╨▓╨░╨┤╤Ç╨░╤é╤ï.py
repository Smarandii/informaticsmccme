a,b=(int,input().split())
for x in range(a,b):
    print(x,"*",x,"=",x*x)