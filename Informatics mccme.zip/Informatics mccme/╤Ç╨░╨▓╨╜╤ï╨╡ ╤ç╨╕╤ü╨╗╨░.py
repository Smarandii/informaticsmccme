a,b,c=map(int,input().split())
if a==b==c:
    print(3)
elif a==b or a==c or b==c:
    print(2)
elif a!=b!=c:
    print(0)

